package com.dendro.recommender.client;/**
 * Created by joaorocha on 22/07/14.
 */
public class Client {
  public static void main(String[] argv) {
      System.out.println("Cliente iniciado");
  }
}
