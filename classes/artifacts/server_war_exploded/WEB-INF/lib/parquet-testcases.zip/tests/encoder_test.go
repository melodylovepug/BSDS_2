package main

import (
	"github.com/TuneLab/goparquet/parquet"
	"github.com/TuneLab/goparquet/parquet/thrift"
	"github.com/TuneLab/goparquet/utils"
	"os"
	"reflect"
	"runtime"
	"strings"
	"sync"
	"testing"
)

var waitgroup1, waitgroup2 sync.WaitGroup

func encodingSingleFile(t *testing.T, name string, dir string) {
	defer waitgroup1.Done()
	var records []map[string]interface{}

	message, err := utils.SchemaParser(dir + "/" + name + ".schema")
	if err != nil {
		t.Errorf("error reading schema:%s, %s\n", dir+"/"+name+".schema", err)
		return
	}

	schema, err := utils.ConvertSchema(message)
	if err != nil {
		t.Errorf("error converting schema :%s, %s\n", dir+"/"+name+".schema", err)
		return
	}

	jsonRows, err := utils.JsonParser(dir+"/"+name+".json", 0x7fffffff)
	if err != nil {
		t.Errorf("error reading json:%s, %s\n", dir+"/"+name+".json", err)
		return
	}

	cols := (*message).Columns
	for _, jsonRow := range jsonRows {
		row := make(map[string]interface{})
		for key, val := range jsonRow {
			if colType, ok := cols[key]; ok {
				utils.NormalizeRow(&row, colType.GetTypeValue(), val, key)

			} else {
				t.Logf("error while reading :%s", dir+"/"+name+".json, schema "+key+" not found\n")
			}
		}
		records = append(records, row)
	}

	// make encoder properties
	prop := parquet.EncoderProperties{
		RGStrategy:      &parquet.SimplePartitionStrategy{RecordThreshold: 10000},
		EncodingType:    thrift.Encoding_PLAIN,
		CompressionType: thrift.CompressionCodec_UNCOMPRESSED,
	}

	// make a file writer
	// open output file
	fo, err := os.Create(dir + "/" + name + "_go.parquet")
	if err != nil {
		t.Fatalf("error creating new parquet file: %v\n", err)
	}

	// initialize defaultEncoder
	e := parquet.NewEncoder(schema, fo, &prop)

	// feed it the record
	e.WriteRecords(records)
	e.Close()

	t.Log(name + "_go.parquet written")

}

// write/generate parquet files from json and schema files
func encodingParquetFiles(t *testing.T, dir string) {
	var visited map[string]bool
	visited = make(map[string]bool)

	fileInfo, err := utils.ReadTestDir(dir)
	if err != nil {
		t.Fatalf("failed reading the testdata directory: %s\n", err)
	}

	newFileInfo := utils.Reset(t, dir, fileInfo)

	for _, file := range newFileInfo {
		if file.IsDir() {
			continue
		}
		name := strings.Split(file.Name(), ".")
		if visited[name[0]] || name[0] == "" {
			continue
		}

		visited[name[0]] = true

		//t.Logf(name[0] + ":\n")

		waitgroup1.Add(1)
		go encodingSingleFile(t, name[0], dir)
	}
	waitgroup1.Wait()
}

func comparePairFiles(t *testing.T, name string, dir string) {
	defer waitgroup2.Done()
	originalParquetRows, err := utils.ParquetParser(dir + "/" + name + ".parquet")
	if err != nil {
		t.Errorf("error reading :%s, %s\n", dir+"/"+name+".parquet", err)
		return
	}

	goParquetRows, err := utils.ParquetParser(dir + "/" + name + "_go.parquet")
	if err != nil {
		t.Errorf("error reading :%s, %s\n", dir+"/"+name+".parquet", err)
		return
	}

	result := true
	for idx, _ := range originalParquetRows {
		if !reflect.DeepEqual(goParquetRows[idx], originalParquetRows[idx]) {
			t.Logf("FROM Go: %s", goParquetRows[idx])
			t.Logf("FROM Java: %s", originalParquetRows[idx])
			t.Logf("Dismatch at index %d", idx)
			result = false
			break
		}
	}
	if result {
		t.Logf("PASSED:\t%s", name)
	} else {
		t.Errorf("FAILED:\t%s", name)
	}
}

// compare generated parquet files with original parquet files
func compareParquetFiles(t *testing.T, dir string) {
	var visited map[string]bool
	visited = make(map[string]bool)

	fileInfo, err := utils.ReadTestDir(dir)
	if err != nil {
		t.Fatalf("failed reading the testdata directory: %s\n", err)
	}

	for _, file := range fileInfo {

		if file.IsDir() {
			continue
		}
		name := strings.Split(file.Name(), ".")
		if visited[name[0]] || name[0] == "" {
			continue
		}

		if name[1] == "parquet" && name[0][len(name[0])-3:] == "_go" {
			continue
		}

		visited[name[0]] = true

		//t.Logf(name[0] + ":\n")

		waitgroup2.Add(1)
		go comparePairFiles(t, name[0], dir)
	}
	waitgroup2.Wait()
}

func TestEncodingSmallCases(t *testing.T) {
	runtime.GOMAXPROCS(runtime.NumCPU())
	encodingParquetFiles(t, "testdata/smallcases")
	compareParquetFiles(t, "testdata/smallcases")
}

func TestEncodingLargeCases(t *testing.T) {
	runtime.GOMAXPROCS(runtime.NumCPU())
	encodingParquetFiles(t, "testdata/largecases")
	compareParquetFiles(t, "testdata/largecases")
}
