## Usage ##
Simply run under the tests directory

    go test -v

main.go is used for debugging purpose
## API ##
GetJsonAndSchema() returns the json format and schema structure read from files with a certain name
