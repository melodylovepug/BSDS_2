package main

import (
	"github.com/TuneLab/goparquet/utils"
	"reflect"
	"runtime"
	"strings"
	"sync"
	"testing"
)

var waitgroup sync.WaitGroup

func decodingSingleFile(t *testing.T, name string, dir string) {
	defer waitgroup.Done()
	schema, err := utils.SchemaParser(dir + "/" + name + ".schema")
	if err != nil {
		t.Errorf("error reading :%s, %s\n", dir+"/"+name+".schema", err)
		return
	}

	parquetRows, err := utils.ParquetParser(dir + "/" + name + ".parquet")
	if err != nil {
		t.Errorf("error reading :%s, %s\n", dir+"/"+name+".parquet", err)
		return
	}

	jsonRows, err := utils.JsonParser(dir+"/"+name+".json", 0x7fffffff)
	if err != nil {
		t.Errorf("error reading :%s, %s\n", dir+"/"+name+".json", err)
		return
	}

	cols := (*schema).Columns
	result := true
	for idx, jsonRow := range jsonRows {
		row := make(map[string]interface{})
		for key, val := range jsonRow {
			if colType, ok := cols[key]; ok {
				utils.NormalizeRow(&row, colType.GetTypeValue(), val, key)
			} else {
				t.Errorf("error while reading :%s", dir+"/"+name+".json, schema "+key+" not found\n")
			}
		}
		if !reflect.DeepEqual(row, parquetRows[idx]) {
			t.Logf("jsonRow: %s", jsonRow)
			t.Logf("row: %s", row)
			t.Logf("parquet: %s", parquetRows[idx])
			t.Errorf("Dismatch at index %d", idx)
			result = false
			break
		}
	}
	if result {
		t.Logf("PASSED:\t%s", name)
	} else {
		t.Errorf("FAILED:\t%s", name)
	}
}

// Test all the triplets(.json/.schema/.parquet) under dir
func decodingParquetFiles(t *testing.T, dir string) {
	var visited map[string]bool
	visited = make(map[string]bool)
	fileInfos, err := utils.ReadTestDir(dir)
	if err != nil {
		t.Fatalf("failed reading the testdata directory: %s, %s\n", dir, err)
	}

	// remove the previously generated _go parquet file
	newFileInfo := utils.Reset(t, dir, fileInfos)

	for _, file := range newFileInfo {
		if file.IsDir() {
			continue
		}
		name := strings.Split(file.Name(), ".")
		if visited[name[0]] || name[0] == "" {
			continue
		}

		visited[name[0]] = true

		//t.Logf(name[0] + ":\n")

		waitgroup.Add(1)
		go decodingSingleFile(t, name[0], dir)

	}
	waitgroup.Wait()

}

func TestDecodingSmallCases(t *testing.T) {
	runtime.GOMAXPROCS(runtime.NumCPU())
	decodingParquetFiles(t, "testdata/smallcases")
}

func TestDecodingLargeCases(t *testing.T) {
	runtime.GOMAXPROCS(runtime.NumCPU())
	decodingParquetFiles(t, "testdata/largecases")
}
