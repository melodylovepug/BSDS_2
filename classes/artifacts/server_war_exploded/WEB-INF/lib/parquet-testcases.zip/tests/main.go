package main

import (
	"bytes"
	"fmt"
	"github.com/TuneLab/goparquet/parquet"
	"github.com/TuneLab/goparquet/parquet/memory"
	"github.com/TuneLab/goparquet/parquet/page"
	"github.com/TuneLab/goparquet/parquet/thrift"
	"github.com/TuneLab/goparquet/utils"
	//"log"
	logPackage "github.com/TuneLab/goparquet/parquet/llog"
	"os"
	"reflect"
	"strings"
)

var log *logPackage.Log

func init() {
	log = logPackage.NewLogger(logPackage.DEBUG, "[MAIN] ")
}

func decodeAllParquetFiles() {
	dir := "testdata"
	var visited map[string]bool
	visited = make(map[string]bool)
	fileInfos, err := utils.ReadTestDir(dir)
	if err != nil {
		log.Fatalf("failed reading the testdata directory: %s, %s\n", dir, err)
	}
	for _, file := range fileInfos {
		if file.IsDir() {
			continue
		}
		name := strings.Split(file.Name(), ".")
		if visited[name[0]] || name[0] == "" {
			continue
		}

		visited[name[0]] = true

		// for debugging purpose
		if name[0] != "TestPageBorder_float_r-2560_c-5_mask-optional-repeated" {
			continue
		}

		log.Println(name[0] + ":")

		schema, err := utils.SchemaParser(dir + "/" + name[0] + ".schema")
		if err != nil {
			log.Printf("error reading :%s, %s", dir+"/"+name[0]+".schema\n", err)
			continue
		}
		parquetRows, err := utils.ParquetParser(dir + "/" + name[0] + ".parquet")
		if err != nil {
			log.Printf("error reading :%s, %s", dir+"/"+name[0]+".parquet\n", err)
			continue
		}

		//log.Printf("Parquet content:\n%s\n", parquetRows)

		jsonRows, err := utils.JsonParser(dir+"/"+name[0]+".json", 0x7fffffff)
		if err != nil {
			log.Printf("error reading :%s", dir+"/"+name[0]+".json\n")
			continue
		}

		//log.Printf("Json content:\n%s\n", jsonRows)

		cols := (*schema).Columns
		result := true
		log.Printf("len(jsonRows): %d, len(parquetRows): %d", len(jsonRows), len(parquetRows))
		//log.Printf("row[17]: %s", jsonRows[17])
		for idx, jsonRow := range jsonRows {
			row := make(map[string]interface{})
			for key, val := range jsonRow {
				if colType, ok := cols[key]; ok {
					utils.NormalizeRow(&row, colType.GetTypeValue(), val, key)
				} else {
					log.Printf("error while reading :%s", dir+"/"+name[0]+".json, schema "+key+" not found\n")
				}
			}
			if !reflect.DeepEqual(row, parquetRows[idx]) {
				log.Printf("jsonRow: %s", jsonRow)
				log.Printf("row: %s", row)
				log.Printf("parquet: %s", parquetRows[idx])
				log.Printf("Dismatch at index %d", idx)
				result = false
				break
			}
		}

		if result {
			log.Printf("PASSED:\t%s", name[0])
			//fmt.Printf("results of file %s match\n", name[0])
		} else {
			log.Printf("FAILED:\t%s", name[0])
			//log.Printf("results of file %s does not match\n", name[0])
		}

	}

}

func testEncoder() {

	output := new([]byte)
	w := bytes.NewBuffer(*output)
	preferences := &page.EncodingPreferences{CompressionCodec: thrift.CompressionCodec_UNCOMPRESSED,
		Encoding: thrift.Encoding_PLAIN}
	typeint32 := thrift.Type_BYTE_ARRAY
	typerepeated := thrift.FieldRepetitionType_REQUIRED
	element := &thrift.SchemaElement{Type: &typeint32, RepetitionType: &typerepeated}
	acc := memory.NewWriteAccumulator(element, 10)

	nullmask := []bool{true, false, true, true, true, false, true}
	replevels := []int32{0, 0, 0, 0, 0, 0, 0}
	//data := []bool{true, false, true, true, false, false, true}//{42, 0, 2, 3, 4, 0, 5}
	data := [][]byte{[]byte("abcd"), []byte("defgh"), []byte("i"), []byte("jkl"), []byte("mn"), []byte("op"), []byte("q")}

	for idx, val := range nullmask {
		err := acc.Append(data[idx], val, replevels[idx])
		if err != nil {
			fmt.Println("error while accumulating:", err)
			return
		}
	}
	fmt.Println("Done setting data")

	enc := page.NewPageEncoder(*preferences, element)
	enc.EncodeBatch(acc)
	fmt.Printf("Done encoding 1 \n")

	size, _ := enc.BufferedSize()
	fmt.Printf("Size:%v\n", size)

	enc.EncodeBatch(acc)
	fmt.Printf("Done encoding 2 \n")

	size, _ = enc.BufferedSize()
	fmt.Printf("Size:%v\n", size)

	enc.EncodeBatch(acc)
	fmt.Printf("Done encoding 3 \n")

	size, _ = enc.BufferedSize()
	fmt.Printf("Size:%v\n", size)

	enc.Flush(w)

	for _, val := range w.Bytes() {
		fmt.Printf("%X ", val)
	}

}

func testEncoderFlow() {
	// to initialize a default encoder we need a few things:
	// make a schema
	schema := parquet.NewSchema()
	schema.AddColumnFromSpec("first: byte_array optional")
	/**
	schema.AddColumnFromSpec("second: int32 optional")
	schema.AddColumnFromSpec("third: int32 optional")
	**/
	fmt.Printf("  schema: %v, %v\n", schema, schema.Columns()) //, schema.Elements()[0])

	// make a record
	record := make(map[string]interface{})
	//array := make([]int32, 0, 3)
	//array = append(array, 42, 3, 0)

	/**
	record["second"] =  int32(5) //array
	record["third"] =  int32(0) //array

	record1 := make(map[string]interface{})
	record1["first"] = int32(4)
	record1["second"] =  int32(41)
	record1["third"] =  nil
	**/

	/*
		record1 := make(map[string]interface{})
		record1["first"] = nil

		record2 := make(map[string]interface{})
		record2["first"] = int32(5)

		record3 := make(map[string]interface{})
		record3["first"] = int32(0)
	*/

	record1 := make(map[string]interface{})
	record1["first"] = nil

	record2 := make(map[string]interface{})
	record2["first"] = "Hello, Parquet :)"

	record3 := make(map[string]interface{})
	record3["first"] = ""

	records := make([]map[string]interface{}, 0, 1)
	records = append(records, record, record1, record2, record3)

	recordsx := make([]map[string]interface{}, 0, 1)
	recordsx = append(recordsx, record1, record, record2, record, record3, record)

	fmt.Printf("  writing1: %v\n", records)
	fmt.Printf("  writing2: %v\n", recordsx)

	// make encoder properties
	prop := parquet.EncoderProperties{
		RGStrategy:      &parquet.BoundedPartitionStrategy{RowGroupSize: 1024 * 4},
		EncodingType:    thrift.Encoding_PLAIN,
		CompressionType: thrift.CompressionCodec_UNCOMPRESSED,
	}

	// make a file writer
	// open output file
	fname := "testdata/output.parquet"
	fo, err := os.Create(fname)
	if err != nil {
		panic(err)
	}

	// initialize defaultEncoder
	e := parquet.NewEncoder(schema, fo, &prop)

	// feed it the record
	e.WriteRecords(records)
	e.Close()

	// now read the parquet file (fingers crossed)
	fname = "testdata/output_int32.parquet"

	parquetRows, err := utils.ParquetParser(fname)
	if err != nil {
		log.Printf("error reading :%s, %s", fname+"\n", err)
	}
	fmt.Printf("  reading: %v, %T\n", parquetRows, parquetRows)

}

func testEncodingParquet(dir string) {
	var visited map[string]bool
	visited = make(map[string]bool)

	fileInfo, err := utils.ReadTestDir(dir)
	if err != nil {
		log.Fatalf("failed reading the testdata directory: %s\n", err)
	}

	newFileInfo := utils.Reset(nil, dir, fileInfo)

	for _, file := range newFileInfo {
		var records []map[string]interface{}

		if file.IsDir() {
			continue
		}
		name := strings.Split(file.Name(), ".")
		if visited[name[0]] || name[0] == "" {
			continue
		}

		visited[name[0]] = true

		// debugging toggle

		if name[0] != "TestPageBorder_float_r-2560_c-5_mask-optional-repeated" {
			continue
		}

		log.Println(name[0] + ":")

		message, err := utils.SchemaParser(dir + "/" + name[0] + ".schema")
		if err != nil {
			log.Printf("error reading :%s, %s", dir+"/"+name[0]+".schema\n", err)
			continue
		}

		schema, err := utils.ConvertSchema(message)
		if err != nil {
			log.Printf("error converting schema :%s, %s", dir+"/"+name[0]+".schema\n", err)
			continue
		}

		jsonRows, err := utils.JsonParser(dir+"/"+name[0]+".json", 0x7fffffff)
		if err != nil {
			log.Printf("error reading :%s, %s\n", dir+"/"+name[0]+".json", err)
			continue
		}

		cols := (*message).Columns
		//log.Printf("row[17]: %s", jsonRows[17])
		for _, jsonRow := range jsonRows {
			row := make(map[string]interface{})
			for key, val := range jsonRow {
				if colType, ok := cols[key]; ok {
					utils.NormalizeRow(&row, colType.GetTypeValue(), val, key)

				} else {
					log.Printf("error while reading :%s", dir+"/"+name[0]+".json, schema "+key+" not found\n")
				}
			}
			records = append(records, row)
		}

		// make encoder properties
		prop := parquet.EncoderProperties{
			RGStrategy:      &parquet.BoundedPartitionStrategy{RowGroupSize: 1024 * 10},
			EncodingType:    thrift.Encoding_PLAIN,
			CompressionType: thrift.CompressionCodec_UNCOMPRESSED,
		}

		// make a file writer
		// open output file
		fo, err := os.Create(dir + "/" + name[0] + "_go.parquet")
		if err != nil {
			panic(err)
		}

		// initialize defaultEncoder
		e := parquet.NewEncoder(schema, fo, &prop)

		// feed it the record
		e.WriteRecords(records)
		e.Close()

		log.Println(name[0] + "_go.parquet written")

	}
}

func testEncodingCompare(dir string) {
	var visited map[string]bool
	visited = make(map[string]bool)

	fileInfo, err := utils.ReadTestDir(dir)
	if err != nil {
		log.Fatalf("failed reading the testdata directory: %s\n", err)
	}

	for _, file := range fileInfo {

		if file.IsDir() {
			continue
		}
		name := strings.Split(file.Name(), ".")
		if visited[name[0]] || name[0] == "" {
			continue
		}

		if name[1] == "parquet" && name[0][len(name[0])-3:] == "_go" {
			continue
		}

		visited[name[0]] = true

		// debugging toggle

		if name[0] != "TestPageBorder_float_r-2560_c-5_mask-optional-repeated" {
			continue
		}

		log.Println(name[0] + ":")

		originalParquetRows, err := utils.ParquetParser(dir + "/" + name[0] + ".parquet")
		if err != nil {
			log.Printf("error reading :%s, %s", dir+"/"+name[0]+".parquet\n", err)
			continue
		}

		goParquetRows, err := utils.ParquetParser(dir + "/" + name[0] + "_go.parquet")
		if err != nil {
			log.Printf("error reading :%s, %s", dir+"/"+name[0]+".parquet\n", err)
			continue
		}

		//fmt.Printf("Go:\n%v\n", goParquetRows[9:11])
		//fmt.Printf("Java:\n%v\n", originalParquetRows[9:11])

		result := true
		for idx, _ := range originalParquetRows {
			if !reflect.DeepEqual(goParquetRows[idx], originalParquetRows[idx]) {
				log.Printf("FROM Go: %s", goParquetRows[idx])
				log.Printf("FROM Java: %s", originalParquetRows[idx])
				log.Printf("Dismatch at index %d", idx)
				result = false
				break
			}
		}
		if result {
			log.Printf("PASSED:\t%s", name[0])
		} else {
			log.Printf("FAILED:\t%s", name[0])
		}

	}
}

func main() {

	//decodeAllParquetFiles()
	//testEncoder()
	//testEncoderFlow()
	/*	log.Set(log.ERROR, "[TEST]")
		log.Errorf("Error!")
		log.Printf("INFO!")*/
	dir := "testdata/largecases"
	testEncodingParquet(dir)
	testEncodingCompare(dir)

	//testEncoderFlow2()
}
