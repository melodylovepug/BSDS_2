import checksum
import config
import struct


def make_pkt(msg, seq, msg_type):
  length = len(msg)
  checksum_result = 0x0000
  result = bytes()

  pack_fmt_str = "!3h" + str(length) + "s"
  result = struct.pack(pack_fmt_str, msg_type,
                     seq, checksum_result, msg)

  sum_high, sum_low = checksum.checksum_build(result)
  if len(result) > 6:
      result = result[:4] + sum_high + sum_low + result[6:]
  else:
      result = result[:4] + sum_high + sum_low
  return result


def decouple_pkt(pkt):
    length = len(pkt)

    pack_fmt_str = "!3h" + str(length - 6) + "s"
    result = struct.unpack(pack_fmt_str, pkt)

    if len(result) < 3 or (result[0] != config.MSG_TYPE_FIN and len(result[3]) < 2):
        print 'Not enough bytes in the packet'
        return -3, None, None
    if not checksum.checksum_verify(result):
        print 'Checksum failed'
        return -1, None, None

    return result[0], result[1], result[3]
