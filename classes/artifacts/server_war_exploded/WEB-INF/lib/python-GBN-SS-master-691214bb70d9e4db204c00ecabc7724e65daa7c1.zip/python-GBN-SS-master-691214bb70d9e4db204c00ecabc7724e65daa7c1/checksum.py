def checksum_build(pkt):
    check_sum_result = int(0)
    for i in pkt:
        check_sum_result += ord(i)
    while check_sum_result > 0xffff:
        check_sum_result = check_sum_result % 0x10000 + \
                           check_sum_result / 0x10000
    return chr(check_sum_result >> 8), chr(check_sum_result % 0x100)


def checksum_verify(pkt):
    check_sum_result = int(0)
    check_sum_origin = pkt[2]
    for i in range(0, 2):
        check_sum_result += pkt[i] / 0x100 + pkt[i] % 0x100
    for i in pkt[3]:
        check_sum_result += ord(i)
    while check_sum_result > 0xffff:
        check_sum_result = check_sum_result % 0x10000 + \
                           check_sum_result / 0x10000

    if check_sum_result != check_sum_origin:
        return False

    return True
