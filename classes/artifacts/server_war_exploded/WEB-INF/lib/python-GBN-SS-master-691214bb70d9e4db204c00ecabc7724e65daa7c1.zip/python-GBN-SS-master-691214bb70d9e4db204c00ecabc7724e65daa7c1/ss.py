import udt
import packet
import time
import config
import thread
import os

# Stop-And-Wait reliable transport protocol.
class StopAndWait:
  # "msg_handler" is used to deliver messages to application layer
  # when it's ready.
  def __init__(self, local_port, remote_port, msg_handler):
    self.network_layer = udt.NetworkLayer(local_port, remote_port, self)
    self.msg_handler = msg_handler
    self.seq_num = 0
    self.remote_seq = None
    self.last_pkt = None
    self.last_pkt_type = None
    self.FIN = config.FIN_NOT

    self.sync = config.SYN_READY
    self.timestamp = time.time()

    self.sync_lock = thread.allocate_lock()

  # "send" is called by application. Return true on success, false
  # otherwise.
  def send(self, msg):
    # TODO: impl protocol to send packet from application layer.
    # call self.network_layer.send() to send to network layer.

    # Wait(), blocking the send method until ACK is received
    # and the timer() has been finished
    while self.sync != config.SYN_READY:
      pass

    self.sync_lock.acquire()
    pkt = packet.make_pkt(msg, self.seq_num, config.MSG_TYPE_DATA)
    self.seq_num += 1
    self.last_pkt = pkt
    self.last_pkt_type = config.MSG_TYPE_DATA
    self.sync_lock.release()
    self.network_layer.send(pkt)

    self.sync_lock.acquire()
    self.sync = config.SYN_WAIT_ACK
    self.timestamp = time.time()
    self.sync_lock.release()
    thread.start_new(self.timer, (pkt, self.seq_num - 1))

    return True

  def resend_pkt(self, pkt):
    # TODO: impl protocol to send packet from application layer.
    # call self.network_layer.send() to send to network layer.

    self.sync_lock.acquire()
    #self.seq_num += 1
    self.sync = config.SYN_RESEND
    self.sync_lock.release()
    self.network_layer.send(pkt)

    self.sync_lock.acquire()
    self.timestamp = time.time()
    self.sync_lock.release()
    if self.last_pkt_type != config.MSG_TYPE_ACK:
      thread.start_new(self.timer, (pkt, self.seq_num))

    return True
  # "handler" to be called by network layer when packet is ready.
  def handle_arrival_msg(self):
    msg = self.network_layer.recv()
    # TODO: impl protocol to handle arrived packet from network layer.
    # call self.msg_handler() to deliver to application layer.
    msg_type, seq, payload = packet.decouple_pkt(msg)

    if msg_type <= 0:
      print 'Malformed pkt received'
      if self.last_pkt is not None:
        print 'resend pkt'
        #self.resend_pkt(self.last_pkt)
      return

    if msg_type == config.MSG_TYPE_ACK:
      if len(payload) != 2:
        print 'Got malformed ACK pkt'
        # Resend the last packet
        if self.last_pkt is not None:
          print 'resend pkt'
          #self.resend_pkt(self.last_pkt)
        return
      ack_num = ord(payload[0]) << 8
      ack_num += ord(payload[1])
      # Should not check seq number of ACK packet
      # because the seq might not be consecutive
      # due to re-sending the same ACK packet
      if ack_num != self.seq_num:
        print 'Got unordered ACK pkt#%d' % ack_num
        # Resend the last packet
        if self.last_pkt is not None:
          print 'resend pkt'
          # For Stop_And_Wait algorithm there's no need to call resend
          # because the timer is still running
          # self.resend_pkt(self.last_pkt)
        return
      print 'Got ACK #%d' % ack_num
      if self.FIN == config.FIN_SERVER:
        self.network_layer.shutdown()
        print 'Normal self exit'
        os._exit(0)
      self.sync_lock.acquire()
      self.remote_seq = seq
      self.sync = config.SYN_EXIT_TIMING
      # self.timestamp = None
      self.sync_lock.release()
    elif msg_type == config.MSG_TYPE_DATA:
      if self.remote_seq is not None and seq != self.remote_seq+1:
        print 'Got unordered DATA pkt#%d' % seq
        self.send_ACK(self.remote_seq)
        return
      self.msg_handler(payload)
      #print 'Seq: %d, %s' % (seq, payload)
      self.remote_seq = seq
      self.send_ACK(self.remote_seq)
    elif msg_type == config.MSG_TYPE_FIN:
      if self.remote_seq is not None and seq < self.remote_seq + 1:
        print 'Got unordered FIN pkt'
        self.send_ACK(self.remote_seq)
        return
      print 'Receive FIN'
      self.remote_seq = seq
      # Client got it's FIN, Phase 2
      if self.FIN == config.FIN_CLIENT:
        self.sync = config.SYN_READY
        self.send_ACK(self.remote_seq)
        time.sleep(2)
        self.network_layer.shutdown()
        print 'Normal self exit'
        os._exit(0)
      # Every time you receive a FIN pkt you should send back an ACK pkt
      self.send_ACK(self.remote_seq)
      # Server got it's FIN, Phase 1
      self.shutdown(config.FIN_SERVER)
      # In case last ACK is missed
      thread.start_new_thread(self.force_exit, ())
    return


  # Cleanup resources.
  def shutdown(self, identity=config.FIN_CLIENT):
    # TODO: cleanup anything else you may have when implementing this
    # class.

    # Wait(), blocking the send method until ACK is received
    while self.sync != config.SYN_READY:
      pass

    pkt = packet.make_pkt("", self.seq_num, config.MSG_TYPE_FIN)
    self.last_pkt = pkt
    self.last_pkt_type = config.MSG_TYPE_FIN
    self.FIN = identity
    self.seq_num += 1
    self.network_layer.send(pkt)

    self.sync_lock.acquire()
    self.sync = config.SYN_WAIT_ACK
    self.timestamp = time.time()
    self.sync_lock.release()
    thread.start_new(self.timer, (pkt, self.seq_num - 1))

    print 'Shutdown called'


  def timer(self, pkt, seq_num):
    #count = 0
    timeout = config.RTT_MSEC + 300
    while self.sync != config.SYN_EXIT_TIMING: #and count < config.RETRY_TIMES:
      if (time.time() - self.timestamp)*1e3 > timeout:
        print 'Timeout on pkt#%d' % seq_num
        self.network_layer.send(pkt)
        self.sync_lock.acquire()
        self.timestamp = time.time()
        self.sync_lock.release()
        #count += 1

    # if count == config.RETRY_TIMES:
    #   print 'Pkt#%d delivery failed' % seq_num
    self.sync = config.SYN_READY

  def send_ACK(self, seq):
    while self.sync != config.SYN_READY and self.sync != config.SYN_EXIT_TIMING:
      pass
    seq += 1
    payload = str(chr(seq / 0x100) + chr(seq % 0x100))
    self.sync_lock.acquire()
    pkt = packet.make_pkt(payload, self.seq_num, config.MSG_TYPE_ACK)
    self.last_pkt = pkt
    self.last_pkt_type = config.MSG_TYPE_ACK
    self.seq_num += 1
    self.sync_lock.release()
    self.network_layer.send(pkt)

    print 'ACK #%d sent' % seq

    return True

  def force_exit(self):
    time.sleep(5)
    print 'Force timeout exit'
    self.network_layer.shutdown()
    os._exit(0)
