import udt
import packet
import time
import config
import thread
import os

class status:
  def __init__(self, packet, status, seq_num):
    self.pkt = packet
    self.s = status
    self.seq = seq_num


# Go-Back-N reliable transport protocol.
class GoBackN:
  # "msg_handler" is used to deliver messages to application layer
  # when it's ready.
  def __init__(self, local_port, remote_port, msg_handler):
    self.network_layer = udt.NetworkLayer(local_port, remote_port, self)
    self.msg_handler = msg_handler
    self.base = 1
    self.next_seq_num = 1
    self.buffer = list()
    self.sync = config.SYN_READY

  # "send" is called by application. Return true on success, false
  # otherwise.
  def send(self, msg):
    # TODO: impl protocol to send packet from application layer.
    # call self.network_layer.send() to send to network layer.
    while self.sync != config.SYN_READY or \
                    self.next_seq_num >= self.base + config.WINDOWN_SIZE:
      pass

    self.sync_lock.acquire()
    pkt = packet.make_pkt(msg, self.next_seq_num, config.MSG_TYPE_DATA)
    self.buffer.append(status(pkt, config.SYN_WAIT_ACK, self.next_seq_num))
    self.next_seq_num += 1
    self.sync_lock.release()
    self.network_layer.send(pkt)

    if self.next_seq_num == self.base+1:
      self.timestamp = time.time()
      thread.start_new(self.timer, (pkt, self.next_seq_num - 1))

    return True


  def resend_pkt(self, pkt):
    # TODO: impl protocol to send packet from application layer.
    # call self.network_layer.send() to send to network layer.

    self.network_layer.send(pkt)

    if self.next_seq_num == self.base+1:
      # self.sync = config.SYN_EXIT_TIMING
      # while self.sync != config.SYN_READY:
      #   pass
      self.timestamp = time.time()
      thread.start_new(self.timer, (pkt, self.next_seq_num - 1))

    return True

  # "handler" to be called by network layer when packet is ready.
  def handle_arrival_msg(self):
    msg = self.network_layer.recv()
    # TODO: impl protocol to handle arrived packet from network layer.
    # call self.msg_handler() to deliver to application layer.
    msg_type, seq, payload = packet.decouple_pkt(msg)

    if msg_type <= 0:
      print 'Malformed pkt received'
      if self.buffer is not None:
        print 'resend pkt'
        self.resend_pkt(self.buffer[-1].pkt)
      return

    if msg_type == config.MSG_TYPE_ACK:
      if len(payload) != 2:
        print 'Got malformed ACK pkt'
        # Resend the last packet
        if self.buffer is not None:
          print 'resend pkt'
          self.resend_pkt(self.buffer[-1].pkt)
        return
      ack_num = ord(payload[0]) << 8
      ack_num += ord(payload[1])
      # Should not check seq number of ACK packet
      # because the remote seq might not be consecutive
      # due to re-sending the same ACK packet
      if ack_num != self.next_seq_num:
        print 'Got unordered ACK pkt#%d' % ack_num
        # Resend the expected packet
        if ack_num - self.base > config.WINDOWN_SIZE:
          print 'The remote side is cheating us, exit!'
          self.resend_pkt(self.buffer[-1].pkt)
        elif self.buffer is not None:
          print 'resend expected ack pkt'
          self.resend_pkt(self.buffer[ack_num - self.base].pkt)
        return
      print 'Got ACK #%d' % ack_num
      if self.FIN == config.FIN_SERVER:
        self.network_layer.shutdown()
        print 'Normal self exit'
        os._exit(0)
      self.sync_lock.acquire()
      self.remote_seq = seq
      self.buffer[ack_num-self.base].s = config.SYN_ACK
      if ack_num == self.base + 1:
        self.sync = config.SYN_EXIT_TIMING
      self.sync_lock.release()
    elif msg_type == config.MSG_TYPE_DATA:
      if self.remote_seq is not None and seq != self.remote_seq+1:
        print 'Got unordered DATA pkt#%d' % seq
        self.send_ACK(self.remote_seq)
        return
      self.msg_handler(payload)
      #print 'Seq: %d, %s' % (seq, payload)
      self.remote_seq = seq
      self.send_ACK(self.remote_seq)
    elif msg_type == config.MSG_TYPE_FIN:
      if self.remote_seq is not None and seq < self.remote_seq + 1:
        print 'Got unordered FIN pkt'
        self.send_ACK(self.remote_seq)
        return
      print 'Receive FIN'
      self.remote_seq = seq
      # Client got it's FIN, Phase 2
      if self.FIN == config.FIN_CLIENT:
        self.sync = config.SYN_READY
        self.send_ACK(self.remote_seq)
        time.sleep(2)
        self.network_layer.shutdown()
        print 'Normal self exit'
        os._exit(0)
      # Every time you receive a FIN pkt you should send back an ACK pkt
      self.send_ACK(self.remote_seq)
      # Server got it's FIN, Phase 1
      self.shutdown(config.FIN_SERVER)
      # In case last ACK is missed
      thread.start_new_thread(self.force_exit, ())


  # Cleanup resources.
  def shutdown(self):
    # TODO: cleanup anything else you may have when implementing this
    # class.
    self.network_layer.shutdown()

  def timer(self, pkt, seq_num):
    timeout = config.TIMEOUT_MSEC
    while self.sync != config.SYN_EXIT_TIMING:
      if (time.time() - self.timestamp) * 1e3 > timeout:
        print 'Timeout on pkt#%d' % seq_num
        for i in self.buffer:
          self.network_layer.send(i.pkt)
        self.sync_lock.acquire()
        self.timestamp = time.time()
        self.sync_lock.release()
    while self.base < self.next_seq_num and \
                    self.buffer[0].s == config.SYN_ACK:
      self.buffer.pop(0)
      self.base += 1
    if len(self.buffer) > 0:
      self.timestamp = time.time()
      thread.start_new_thread(self.timer, (self.buffer[0].pkt, self.buffer[0].seq))
    self.sync = config.SYN_READY


