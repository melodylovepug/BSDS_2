# Port numbers used by unreliable network layers.
SENDER_LISTEN_PORT = 8080
RECEIVER_LISTEN_PORT = 8081

# Parameters for unreliable network.
BIT_ERROR_PROB = 0.0
MSG_LOST_PROB = 0.0
RTT_MSEC = 100

# Parameters for transport protocols.
TIMEOUT_MSEC = 150
WINDOWN_SIZE = 20

# Packet size for network layer.
MAX_SEGMENT_SIZE = 512
# Packet size for transport layer.
MAX_MESSAGE_SIZE = 500

# Message types used in transport layer.
MSG_TYPE_DATA = 1
MSG_TYPE_ACK = 2
MSG_TYPE_FIN = 3

# FIN status
FIN_NOT = 0
FIN_CLIENT = 1
FIN_SERVER = 2

# Retry times when timeout
RETRY_TIMES = 10

# Sync status
SYN_READY = 0
SYN_WAIT_ACK = 1
SYN_RESEND = 2
SYN_EXIT_TIMING = 3
SYN_ACK = 4

