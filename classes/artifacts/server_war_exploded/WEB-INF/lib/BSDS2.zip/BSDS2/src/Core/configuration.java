package Core;

/**
 * Created by Yuga on 11/20/16.
 */
public class configuration {
    public static final String baseURL = "http://localhost:8080/api/BSDS/";
}
