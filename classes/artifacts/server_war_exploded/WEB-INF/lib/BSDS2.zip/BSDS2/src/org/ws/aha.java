package org.ws;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.PathParam;
import javax.ws.rs.core.MediaType;
import Core.CAServer;
import javax.ws.rs.core.Response;
import org.json.*;
import org.json.simple.JSONObject;





// Plain old Java Object it does not extend as class or implements
// an interface

// The class registers its methods for the HTTP GET request using the @GET annotation.
// Using the @Produces annotation, it defines that it can deliver several MIME types,
// text, XML and HTML.

// The browser requests per default the HTML MIME type.

//Sets the path to base URL + /hello

//@Produces(MediaType.TEXT_HTML)
//@Consumes(MediaType.TEXT_HTML)
@Path("/hello")
public class aha {
    //private CAServer caserver = new CAServer();


    private static Integer it = 666;

    // This method is called if TEXT_PLAIN is request
    @GET
    @Produces(MediaType.TEXT_PLAIN)
    public String sayPlainTextHello() {
        return "Hello Jersey " + it.toString();
    }

    // This method is called if XML is request
    @GET
    @Produces(MediaType.TEXT_XML)
    public String sayXMLHello() {
        return "<?xml version=\"1.0\"?>" + "<hello> Hello Jersey" + "</hello>";
    }

    // This method is called if HTML is request
    @GET
    @Produces(MediaType.TEXT_HTML)
    public String sayHtmlHello() {
        return "<html> " + "<title>" + "Hello Jersey" + "</title>"
                + "<body><h1>" + "Hello Jersey " + it.toString() + "</body></h1>" + "</html> ";
    }

    @GET
    @Path("/registerPublisherResource/{topic}")
    //@Produces(MediaType.TEXT_HTML)
    public String registerPublisherResource(@PathParam("topic")  String topic) {
/*
        int id = caserver.registerPublisher(topic);

        JSONStringer json = new JSONStringer();
        try {
            json.object().key("pubtopic").value(id).endObject();
        } catch (Exception e) {}

        System.out.println(json.toString());

        return Response.ok(json.toString()).build();*/

        return "haha";
    }
/*
    @POST
    @Path("/{publicContentResource/{int}/{message}}")
    public Response publicContentResource(@PathParam("int") final int id, @PathParam("message") final String message) {
        caserver.publishContent(id, message);
        return Response.ok(200).build();

    }

    @POST
    @Path("/{registerSubscriber/{topic}}")
    public Response registerSubscriberResource(@PathParam("topic") final String topic){
        int id = caserver.registerSubscriber(topic);

        JSONStringer json = new JSONStringer();
        try {
            json.object().key("subtopic").value(id).endObject();
        } catch (Exception e) {
        }
        System.out.println(json.toString());

        return Response.ok(json.toString()).build();
    }


    @GET
    @Path("/{getLatestConect/{subId}}")
    public Response getLatestContentResource(@PathParam("subId") final int subId)
    {
        String message = caserver.getLatestContent(subId);
        JSONStringer json = new JSONStringer();
        try {
            json.object().key("message").value(message).endObject();
        } catch (Exception e) {
        }
        System.out.println(json.toString());

        return Response.ok(json.toString()).build();
    }
*/
}